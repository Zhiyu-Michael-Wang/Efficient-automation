package com.example.learning2.ui.main;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.learning2.R;
import com.example.learning2.ToDoDataBaseHelper;
import com.google.android.material.snackbar.Snackbar;


import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link toDoFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link toDoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class toDoFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    RecyclerView toDoList;
    ImageButton addEvent;
    toDoAdapter mAdapter;
    List<Event> eventList = new ArrayList<Event>();


    private EditText titleEnter, subTitleEnter, processEnter, totalEnter;

    private ToDoDataBaseHelper dbHelper;

/*
    public class Event {
        String mTitle;
        String mSubTitle;
        int mFinish;
        int mNeed;

        public Event(String mTitle, String mSubTitle, int finish, int mNeed)
        {
            mTitle=mTitle;
            mSubTitle=mSubTitle;
            mFinish=finish;
            mNeed=mNeed;
        }
    }
*/


    public class toDoAdapter extends RecyclerView.Adapter<toDoAdapter.viewHolder>{//////////////////////////////

        private List<Event> eventList;
        private AdapterView.OnItemLongClickListener mOnItemLongClickListener;
        private AdapterView.OnItemClickListener mOnItemClickListener;

        public toDoAdapter(List<Event> eventList){
            this.eventList = eventList;
        }




        private class viewHolder extends RecyclerView.ViewHolder{

            private TextView mTitle;
            private TextView mSubTitle;
            private ProgressBar haveDone;
            private EditText mProgress;
            private EditText mTotal;
            private ImageButton addButton;

            public viewHolder(LayoutInflater inflater, ViewGroup parent){
                super(inflater.inflate(R.layout.to_do_item, parent,false ));

                mTitle = (TextView)itemView.findViewById(R.id.title);
                mSubTitle=(TextView)itemView.findViewById(R.id.subTitle);
                mProgress=(EditText)itemView.findViewById(R.id.numFinish);
                mTotal=(EditText)itemView.findViewById(R.id.numNeed);
                haveDone = itemView.findViewById(R.id.haveDone);
                addButton = itemView.findViewById(R.id.addButton);



            }

            public void bind(Event thisEvent) {
                mTitle.setText(thisEvent.mTitle);
                mSubTitle.setText(thisEvent.mSubTitle);
                mProgress.setHint(String.valueOf(thisEvent.mFinish));
                mTotal.setHint(String.valueOf(thisEvent.mNeed));
                haveDone.setMax(thisEvent.mNeed);
                haveDone.setProgress(thisEvent.mFinish);
            }
        }

        @Override
        public viewHolder onCreateViewHolder(ViewGroup parent, int ViewType){
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new viewHolder(layoutInflater,parent);
        }

        @Override
        public void onBindViewHolder(final viewHolder viewHolder, final int position){
            viewHolder.bind(eventList.get(position));
            final com.example.learning2.ui.main.Event event = eventList.get(position);
            viewHolder.mTitle.setText(event.mTitle);
            viewHolder.mSubTitle.setText(event.mSubTitle);

            viewHolder.mProgress.setText(String.valueOf(event.mFinish));                //  错误 viewHolder.mProgress.setText(event.mFinish);
            viewHolder.mTotal.setText(String.valueOf(event.mNeed));                                       //  错误 viewHolder.mTotal.setText(event.mNeed);




         //   viewHolder.haveDone.setMax(Integer.valueOf(viewHolder.mProgress.getText().toString()));
         //   viewHolder.haveDone.setProgress(Integer.valueOf(viewHolder.mTotal.getText().toString()));

            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int process = viewHolder.haveDone.getProgress();
                    viewHolder.haveDone.setProgress(++process);
                    viewHolder.mProgress.setText(process + "");
                    Snackbar.make(view,"One step further: " + process + "/" + viewHolder.haveDone.getMax(), Snackbar.LENGTH_SHORT)
                            .setAction("Already completed?", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Snackbar.make(view,"Finished!", Snackbar.LENGTH_SHORT).show();
                                }
                            }).show();
                    update(process, position);
                    if(process>=viewHolder.haveDone.getMax()){
                        eventList.remove(position);
                        delete(position);
                        mAdapter.notifyDataSetChanged();
                        Snackbar.make(view,"Finished!", Snackbar.LENGTH_SHORT).show();
                    }
                }
            });

        }


        public void add(Event event){
            eventList.add(event);
        }

        public Event getEvent(int position)
        {
            return  eventList.get(position);
        }

        public void remove(int position)
        {
            eventList.remove(position);
        }
        /*///////////////////////////
        private OnRecyclerViewClickListener listener;
        public void setItemClickListener(OnRecyclerViewClickListener itemClickListener) {
            listener = itemClickListener;
        }
        *////////////////////////////





        @Override
        public int getItemCount(){
            return eventList.size();
        }


        public final AdapterView.OnItemLongClickListener getOnItemLongClickListener() {
            return mOnItemLongClickListener;
        }

        public final AdapterView.OnItemClickListener getOnItemClickListener() {
            return mOnItemClickListener;
        }

        public void setOnItemClickListener(@Nullable AdapterView.OnItemClickListener listener) {
            mOnItemClickListener = listener;
        }

    }
   // private OnFragmentInteractionListener mListener;

    public toDoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment toDoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static toDoFragment newInstance(String param1, String param2) {
        toDoFragment fragment = new toDoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        dbHelper = new ToDoDataBaseHelper(getActivity(),"toDoItems.db",null,1);
        dbHelper.getWritableDatabase();





    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_to_do, container, false);


        toDoList = view.findViewById(R.id.toDoList);
        toDoList.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUI();

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent eventData) {
        super.onActivityResult(requestCode, resultCode, eventData);
        if(requestCode==Codes.REQUEST_ADD_EVENT && resultCode==Codes.RESULT_ADD_EVENT){
            String getTitle=eventData.getStringExtra(Codes.TITLE);
            String getSubTitle=eventData.getStringExtra(Codes.SUBTITLE);
            int getProcess=eventData.getIntExtra(Codes.PROCESS,0);
            int getTotal=eventData.getIntExtra(Codes.Total, 10);

        //    Event event = new Event(getTitle,getSubTitle,getProcess,getTotal);

/*
            titleEnter = (EditText)getActivity().findViewById(R.id.titleEnter);
            subTitleEnter = (EditText)getActivity().findViewById(R.id.subTitleEnter);
            processEnter = (EditText)getActivity().findViewById(R.id.processEnter);
            totalEnter = (EditText)getActivity().findViewById(R.id.totalEnter);
            */
            long id = insert(getTitle,getSubTitle,getProcess,getTotal);
            Event event = new Event(id,getTitle,getSubTitle,getProcess,getTotal);

            mAdapter.add(event);
            mAdapter.notifyDataSetChanged();
        }


    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);

        //dbHelper = new ToDoDataBaseHelper(getActivity(),"toDoItems.db",null,1);


        ImageButton addEvent = (ImageButton)getActivity().findViewById(R.id.addEvent);
        addEvent.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Activity  activity = getActivity();
                Intent Intent = new Intent(activity,addEventActivity.class);
                startActivityForResult(Intent,Codes.REQUEST_ADD_EVENT);


            }
        });
    }

    public void query(){
        try {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            Cursor cursor = db.query("Table_Event", null, null, null, null, null, null);//问题所在

            if (cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndex("id"));
                    String getTitle = cursor.getString(cursor.getColumnIndex("mTitle"));
                    String getSubTitle = cursor.getString(cursor.getColumnIndex("mSubTitle"));
                    String tem = cursor.getString(cursor.getColumnIndex("mProcess"));
                    int getProcess = Integer.valueOf(tem);
                    tem = cursor.getString(cursor.getColumnIndex("mTotal"));
                    int getTotal = Integer.valueOf(tem);

                    Event event = new Event(id,getTitle, getSubTitle, getProcess, getTotal);
                    mAdapter.add(event);
                    //mAdapter.notifyDataSetChanged();
                } while (cursor.moveToNext());
                mAdapter.notifyDataSetChanged();
            }
            cursor.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public long insert(String title,String subTitle, int process, int total){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
/*
        values.put("mTitle",titleEnter.getText().toString());
        values.put("mSubTitle",subTitleEnter.getText().toString());
        String tem=processEnter.getText().toString();
        values.put("process",Integer.valueOf(tem));
        tem=totalEnter.getText().toString();
        values.put("total",Integer.valueOf(tem));
*/
        values.put("mTitle", title);
        values.put("mSubTitle", subTitle);
        values.put("mProcess", process);
        values.put("mTotal", total);

      return  db.insert("Table_Event", null, values);

        //db.insert("Events", null, values);

    }

    public void update(int process, int position){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Event event = mAdapter.getEvent(position);
        String[] args = {String.valueOf(event.mId)};
        ContentValues contentValues = new ContentValues();
        contentValues.put("mProcess",process);
        db.update("Table_Event", contentValues, "id = ?", args);
    }

    public void delete(int position){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Event event = mAdapter.getEvent(position);
        String[] args = {String.valueOf(event.mId)};
        db.delete("Table_Event", "id = ?",args);
        mAdapter.remove(position);
    }



    private void updateUI() {


        List<Event> eventList = new ArrayList<Event>();


    /*    String getTitle=getActivity().getIntent().getStringExtra("Title");
        int getFinish=getActivity().getIntent().getIntExtra("Process", 10);
        int getTotal=getActivity().getIntent().getIntExtra("Total", 100);
*/
/*
        Event p = new Event("This is from","updateUI",10,100);
        eventList.add(p);
*/
        mAdapter = new toDoAdapter(eventList);
        toDoList.setAdapter(mAdapter);

        query();//问题


        /*for(int i = 0; i<10;i++) {
            p = new Event(mParam1,"Subtitle",i, 100);
            aa.add(p);
        }*/




    }



}
