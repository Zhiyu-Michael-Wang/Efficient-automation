package com.example.learning2.ui.main;

import java.io.Serializable;

public class Event implements Serializable {
    long mId;
    String mTitle;
    String mSubTitle;
    int mFinish;
    int mNeed;

    public Event(long id,String getTitle, String getSubTitle, int getProcess, int getTotal) {
        mId = id;
        mTitle = getTitle;
        mSubTitle = getSubTitle;
        mFinish = getProcess;
        mNeed = getTotal;
    }
}
