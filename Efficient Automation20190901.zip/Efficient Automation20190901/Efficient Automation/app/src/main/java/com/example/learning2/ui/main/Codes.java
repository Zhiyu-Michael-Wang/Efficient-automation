package com.example.learning2.ui.main;

public class Codes {

    public static int REQUEST_ADD_EVENT =10;
    public static int RESULT_ADD_EVENT = 1;

    public static String TITLE="Title";
    public static String SUBTITLE="SubTitle";
    public static String PROCESS="Process";
    public static String Total="Total";

    public static String EVENTS_TABLE="Events";
}
