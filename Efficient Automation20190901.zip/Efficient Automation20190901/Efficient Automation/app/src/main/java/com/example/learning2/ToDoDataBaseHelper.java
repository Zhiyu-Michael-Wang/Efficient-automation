package com.example.learning2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ToDoDataBaseHelper extends SQLiteOpenHelper {

    public static final String CREATE_EVENT = "create table Table_Event ("
            + "id integer primary key autoincrement, "
            + "mTitle text, "
            + "mSubTitle text, "
            + "mProcess integer, "
            + "mTotal integer)";

    private Context mContext;

    public ToDoDataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_EVENT);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }
}
