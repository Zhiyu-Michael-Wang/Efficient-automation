package com.example.learning2;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.ViewParent;
import android.widget.CalendarView;

import com.example.learning2.ui.main.SectionsPagerAdapter;

public class MainActivity extends AppCompatActivity {


    boolean clicked=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
    //    final boolean clicked;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager Pages = findViewById(R.id.Pages);
        Pages.setOffscreenPageLimit(2);
        Pages.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(Pages);

        tabs.getTabAt(1).select();



        FloatingActionButton fab = findViewById(R.id.finishFab);
        CalendarView calenderView = findViewById(R.id.calendarView);
        calenderView.setVisibility(View.GONE);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CalendarView calenderView = findViewById(R.id.calendarView);


                if(clicked==true){
                    calenderView.setVisibility(View.GONE);
                    clicked=false;
                }

                else{
                    calenderView.setVisibility(View.VISIBLE);
                    clicked=true;
                }

            }
        });
    }
}