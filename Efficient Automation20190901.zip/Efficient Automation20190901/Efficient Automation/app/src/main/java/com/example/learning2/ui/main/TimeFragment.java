package com.example.learning2.ui.main;


import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;

import com.example.learning2.R;
import com.google.android.material.snackbar.Snackbar;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TimeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TimeFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;



    ProgressBar mainTimer;
    int mainTimeCount;
    ProgressBar subTimer;
    int subTimeCount;
    int totalTimeCount;
    int totalTimeMax;

    Switch ifSub;
    boolean ifMain;
    boolean ifCount;

    TextView resetWorkTime;
    TextView resetBreakTime;
    TextView workTimeLeft;
    TextView elasticTimeLeft;
    EditText addWorkTime;
    EditText addBreakTime;
    ImageButton startButton;
    ImageButton pauseButton;
    SoundPool soundPool;

    TextView test; //******************************
    int i,j;

    boolean justReset;

    int sourceId_notify;
    int sourceId_end;


    private boolean ended=false;

    public TimeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TimeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TimeFragment newInstance(String param1, String param2) {
        TimeFragment fragment = new TimeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_time, container, false);

       ProgressBar mainTimer = v.findViewById(R.id.mainTimer);
       mainTimer.setMax(60);
       mainTimer.setProgress(50);
       ProgressBar subTimer = v.findViewById(R.id.subTimer);
       subTimer.setMax(60);
       subTimer.setProgress(50);


        return v;
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);

        ImageButton resetTimeButton = (ImageButton)getActivity().findViewById(R.id.resetTimeButton);
        ImageButton addTimeButton = (ImageButton)getActivity().findViewById(R.id.addTimeButton);
        startButton = (ImageButton)getActivity().findViewById(R.id.startButton);
        pauseButton = (ImageButton)getActivity().findViewById(R.id.pauseButton);

        resetWorkTime = (TextView)getActivity().findViewById(R.id.resetWorkTime);
        resetBreakTime = (TextView)getActivity().findViewById(R.id.resetBreakTime);
        addWorkTime = (EditText)getActivity().findViewById(R.id.addWorkTime);
        addWorkTime.setText("");
        addBreakTime = (EditText)getActivity().findViewById(R.id.addBreakTime);
        addBreakTime.setText("");

        workTimeLeft = (TextView)getActivity().findViewById(R.id.workTimeLeft);
        elasticTimeLeft = (TextView)getActivity().findViewById(R.id.elasticTimeLeft);

        soundPool = new SoundPool(2, AudioManager.STREAM_SYSTEM, 5);
        sourceId_notify = soundPool.load(getContext(),R.raw.notify, 0);
        sourceId_end = soundPool.load(getContext(), R.raw.time_end, 1);


        test = (TextView)getActivity().findViewById(R.id.test);//*****************************************
        i=2;
        j=0;


        justReset = false;


        resetTimeButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Snackbar.make(arg0,getString(R.string.going_reset), Snackbar.LENGTH_SHORT)
                        .setAction(getString(R.string.sure )+ "?", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                resetAll(mainTimer.getMax(),subTimer.getMax());

                                Snackbar.make(view,getString(R.string.reset_successful), Snackbar.LENGTH_SHORT)
                                        .setAction(getString(R.string.reset_all) + "?", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                resetAll(0, 0);
                                                justReset = true;


                                            }
                                        }).show();
                            }
                        }).show();

            }
        });


        addTimeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0){

                Snackbar.make(arg0,getString(R.string.going_add), Snackbar.LENGTH_SHORT)
                        .setAction(getString(R.string.sure) + "?", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                int mainTimeAdd;
                                int subTimeAdd;

                                //edit the default time
                                if(!addWorkTime.getText().toString().equals("")) mainTimeAdd = Integer.valueOf(addWorkTime.getText().toString())*60;
                                else mainTimeAdd = 5;//****************************
                                if(!addBreakTime.getText().toString().equals(""))subTimeAdd = Integer.valueOf(addBreakTime.getText().toString())*60;
                                else subTimeAdd = 3;


                                subTimeCount+=subTimeAdd;
                                mainTimeCount+=mainTimeAdd;
                                if(mainTimeCount>=mainTimer.getMax()){
                                    mainTimer.setMax(mainTimeCount);
                                    resetWorkTime.setText(mainTimer.getMax()/60 + ":" + mainTimer.getMax()%60);
                                }
                                if(subTimeCount>=subTimer.getMax()){
                                    subTimer.setMax(subTimeCount);
                                    resetBreakTime.setText(subTimer.getMax()/60 + ":" + subTimer.getMax()%60);
                                }
                                mainTimer.setProgress(mainTimeCount);
                                subTimer.setProgress(subTimeCount);

                                totalTimeCount=subTimeCount+mainTimeCount;
                                totalTimeMax=mainTimer.getMax()+subTimer.getMax();

                                elasticTimeLeft.setText(getString(R.string.elastic_left) + ": " + subTimeCount/60 + ":" + subTimeCount%60);
                                workTimeLeft.setText(getString(R.string.work_left) + ": " + mainTimeCount/60 + ":" + mainTimeCount%60);

                                if(justReset){
                                    resetAll(mainTimer.getMax(), subTimer.getMax());
                                    justReset = false;
                                }


                                Snackbar.make(view,R.string.time_add, Snackbar.LENGTH_SHORT).show();
                            }
                        }).show();

            }
        });


        startButton.setVisibility(View.VISIBLE);
        startButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0){
                if(totalTimeCount>0){
                    startButton.setVisibility(View.INVISIBLE);
                    pauseButton.setVisibility(View.VISIBLE);
                    ifCount = true;
                    mHandler.sendEmptyMessage(1);
                }
                else{
                    Snackbar.make(arg0,getString(R.string.time_runout), Snackbar.LENGTH_SHORT).show();
                }
            }
        });


        pauseButton.setVisibility(View.INVISIBLE);
        pauseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0){
                startButton.setVisibility(View.VISIBLE);
                pauseButton.setVisibility(View.INVISIBLE);
                ifCount = false;
            }
        });

        mainTimer = getActivity().findViewById(R.id.mainTimer);
        subTimer = getActivity().findViewById(R.id.subTimer);
        ifSub = getActivity().findViewById(R.id.ifSub);

        resetAll(0,0);
        startButton.setVisibility(View.VISIBLE);
        pauseButton.setVisibility(View.INVISIBLE);
        ifSub.setChecked(false);

        ifSub.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    ifMain=false;
                    //Todo
                }else {
                    ifMain=true;
                    //Todo
                }
            }
        });
    }

    public void resetAll(int setTime,int setSubTime){
        mainTimer.setMax(setTime);
        mainTimer.setProgress(setTime);
        mainTimeCount=setTime;

        subTimer.setMax(setSubTime);
        subTimer.setProgress(setSubTime);
        subTimeCount=setSubTime;

        totalTimeCount=mainTimeCount+subTimeCount;
        totalTimeMax=mainTimer.getMax()+subTimer.getMax();

        ifMain=true;
        ifCount=false;
        ended=false;

        ifSub.setChecked(false);

        resetWorkTime.setText(mainTimeCount/60 + ":" + mainTimeCount%60);
        resetBreakTime.setText(subTimeCount/60 + ":" + subTimeCount%60);

        elasticTimeLeft.setText(getString(R.string.elastic_left) + ": " + subTimeCount/60 + ":" + subTimeCount%60);
        workTimeLeft.setText(getString(R.string.work_left) + ": " + mainTimeCount/60 + ":" + mainTimeCount%60);

        startButton.setVisibility(View.VISIBLE);
        pauseButton.setVisibility(View.INVISIBLE);

        i = 2;



    }



    Handler mHandler = new Handler(){
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    removeMessages(1);
/*
                    Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                    Ringtone rt = RingtoneManager.getRingtone(getActivity().getApplicationContext(), uri);
                    rt.setLooping(true);

                    boolean play = false;
*/

                    if(!ended){
                        if(subTimeCount>0 && !ifMain && ifCount){
                            subTimer.setProgress(--subTimeCount);
                            totalTimeCount=mainTimeCount+subTimeCount;
                            elasticTimeLeft.setText(getString(R.string.elastic_left) + ": " + subTimeCount/60 + ":" + subTimeCount%60);

                        }
                        if(subTimeCount<=0 && !ifMain && ifCount){
                            ifMain=true;
                            ifSub.setChecked(false);
                        }

                        if(mainTimeCount>0 && ifMain && ifCount) {
                            mainTimer.setProgress(--mainTimeCount);
                            totalTimeCount=mainTimeCount+subTimeCount;
                            workTimeLeft.setText(getString(R.string.work_left) + ": " + mainTimeCount/60 + ":" + mainTimeCount%60);

                        }


                        if(totalTimeCount==0 || totalTimeMax/totalTimeCount>=i && ifCount){
                            test.setText("now is: " + i);

                            //rt.play();
                            //sourceId = soundPool.load(getContext(),R.raw.notify, 0);
                            soundPool.play(sourceId_notify, 1, 1, 0, 0, 1);

                            i*=2;
                        }



                        if(mainTimeCount<=0 && ifMain && ifCount){
                            ifMain=false;
                            ifSub.setChecked(true);
                        }

                        if(totalTimeCount<=0)ended=true;

                        sendEmptyMessageDelayed(1, 1000);
                    }
                    else{
                        resetAll(0, 0);
                        ended=true;
                        justReset = true;
                        //sourceId = soundPool.load(getContext(),R.raw.time_end, 0);
                        soundPool.play(sourceId_end, 1, 1, 1, 0, 1);


                    }
/*
                    if(rt.isPlaying() || !play)rt.stop();
                    if(!rt.isPlaying() && play)rt.play();
*/


                    break;
            }
        }
    };





}
