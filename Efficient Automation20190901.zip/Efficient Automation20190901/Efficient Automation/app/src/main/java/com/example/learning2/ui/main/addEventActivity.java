package com.example.learning2.ui.main;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.learning2.R;

public class addEventActivity extends AppCompatActivity {

    EditText titleEnter;
    EditText subTitleEnter;
    EditText processEnter;
    EditText totalEnter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        titleEnter=findViewById(R.id.titleEnter);
        subTitleEnter=findViewById(R.id.subTitleEnter);
        processEnter=findViewById(R.id.processEnter);
        totalEnter=findViewById(R.id.totalEnter);

        ImageButton finishButton = findViewById(R.id.finishButton);
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Event e = new Event(0,"","",0,10);
               // totalEnter.setText("10");
               // processEnter.setText("0");

                e.mTitle =titleEnter.getText().toString();
                if(e.mTitle.equals(""))e.mTitle ="...";
                e.mSubTitle =subTitleEnter.getText().toString();
                String tem;
                e.mFinish=0;
                if(!TextUtils.isEmpty(processEnter.getText())){
                    tem = processEnter.getText().toString();
                    e.mFinish=Integer.valueOf(tem);
                }
                else e.mFinish=0;
                if(!TextUtils.isEmpty(totalEnter.getText())){
                    tem=totalEnter.getText().toString();
                    e.mNeed =Integer.valueOf(tem);
                }
                else e.mNeed =10;


                Intent eventData = new Intent();
                eventData.putExtra("NewEvent", e);
                eventData.putExtra(Codes.TITLE, e.mTitle);
                eventData.putExtra(Codes.SUBTITLE, e.mSubTitle);
                eventData.putExtra(Codes.PROCESS, e.mFinish);
                eventData.putExtra(Codes.Total, e.mNeed);

                setResult(Codes.RESULT_ADD_EVENT, eventData);


                finish();
            }
        });



    }

}
